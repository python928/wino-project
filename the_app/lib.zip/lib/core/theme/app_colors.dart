import 'package:flutter/material.dart';

class AppColors {
  // Primary Colors - Updated to match the design
  static const Color primaryOrange = Color(0xFFFF8C42);
  static const Color primaryPurple = Color(0xFF8B5CF6);
  static const Color primaryMagenta = Color(0xFFD946EF);
  
  // Gradient
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryOrange, Color(0xFFFF6B35)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient purpleGradient = LinearGradient(
    colors: [primaryPurple, primaryMagenta],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  // Secondary Colors
  static const Color hotDealRed = Color(0xFFFF3D00);
  static const Color ratingYellow = Color(0xFFFFC107);
  static const Color successGreen = Color(0xFF4CAF50);
  
  // Category Colors
  static const Color categoryElectronics = Color(0xFF00BCD4);
  static const Color categoryFashion = Color(0xFFFF6B9D);
  static const Color categoryHome = Color(0xFFFF9800);
  static const Color categorySports = Color(0xFF9C27B0);
  static const Color categoryFood = Color(0xFFFF5722);
  static const Color categoryBeauty = Color(0xFFE91E63);
  
  // Neutral Colors
  static const Color scaffoldBackground = Color(0xFFF5F5F5);
  static const Color cardWhite = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color textHint = Color(0xFF9E9E9E);
  
  // UI Elements
  static const Color searchBarBackground = Color(0xFFF5F5F5);
  static const Color borderLight = Color(0xFFE0E0E0);
  static const Color shadowColor = Color(0x1A000000);
  
  // Status Colors
  static const Color error = Color(0xFFF44336);
  static const Color warning = Color(0xFFFF9800);
  static const Color info = Color(0xFF2196F3);
  static const Color openStatus = Color(0xFF4CAF50);
  static const Color closedStatus = Color(0xFF9E9E9E);
  
  // Badge Colors
  static const Color badgeOrange = Color(0xFFFF8C42);
  static const Color badgeRed = Color(0xFFFF3B30);
  
  // Shadow
  static BoxShadow primaryShadow = BoxShadow(
    color: primaryOrange.withOpacity(0.3),
    blurRadius: 10,
    offset: const Offset(0, 4),
  );
  
  static BoxShadow cardShadow = BoxShadow(
    color: Colors.grey.withOpacity(0.08),
    blurRadius: 10,
    offset: const Offset(0, 2),
  );
  
  static BoxShadow softShadow = BoxShadow(
    color: Colors.grey.withOpacity(0.1),
    blurRadius: 8,
    offset: const Offset(0, 2),
  );
}