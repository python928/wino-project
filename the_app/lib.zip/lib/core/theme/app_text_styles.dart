import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTextStyles {
  // Headings
  static const TextStyle h1 = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
    height: 1.2,
  );
  
  static const TextStyle h2 = TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
    height: 1.2,
  );
  
  static const TextStyle h3 = TextStyle(
    fontSize: 20,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle h4 = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );
  
  // Body Text
  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.normal,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle bodySmall = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: AppColors.textSecondary,
  );
  
  // Special Styles
  static const TextStyle buttonText = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.cardWhite,
  );
  
  static const TextStyle priceText = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.primaryPurple,
  );
  
  static const TextStyle oldPriceText = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: AppColors.textHint,
    decoration: TextDecoration.lineThrough,
  );
  
  static const TextStyle categoryLabel = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.bold,
    color: AppColors.textPrimary,
  );
  
  static const TextStyle ratingText = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.bold,
    color: AppColors.ratingYellow,
  );
  
  static const TextStyle hintText = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.normal,
    color: AppColors.textHint,
  );
  
  static const TextStyle linkText = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.primaryPurple,
  );
  
  static const TextStyle badgeText = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: AppColors.cardWhite,
  );
  
  static const TextStyle timerText = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.cardWhite,
  );
  
  static const TextStyle discountText = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: AppColors.hotDealRed,
  );
  
  static const TextStyle promoTitle = TextStyle(
    fontSize: 22,
    fontWeight: FontWeight.bold,
    color: AppColors.cardWhite,
    height: 1.2,
  );
  
  static const TextStyle promoSubtitle = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.normal,
    color: Color(0xB3FFFFFF), // 70% opacity white
  );
  
  static const TextStyle navLabelActive = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: AppColors.primaryPurple,
  );
  
  static const TextStyle navLabelInactive = TextStyle(
    fontSize: 10,
    fontWeight: FontWeight.bold,
    color: AppColors.textHint,
  );
}