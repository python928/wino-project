import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../shared_widgets/custom_bottom_nav.dart';
import 'home_screen.dart';
import '../discovery/discovery_screen.dart';
import '../offers/offers_screen.dart';
import '../messages/messages_screen.dart';
import '../profile/profile_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 2; // Start with Home (center)

  // All screens
  final List<Widget> _screens = const [
    DiscoveryScreen(),  // 0 - استكشاف
    OffersScreen(),     // 1 - العروض
    HomeScreen(),       // 2 - الرئيسية (center)
    MessagesScreen(),   // 3 - الرسائل
    ProfileScreen(),    // 4 - حسابي
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      floatingActionButton: _buildFloatingActionButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavBar(
        selectedIndex: _selectedIndex,
        onItemTapped: _onItemTapped,
        messagesBadgeCount: 2,
      ),
    );
  }

  Widget _buildFloatingActionButton() {
    return Container(
      height: 70,
      width: 70,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: AppColors.primaryGradient,
        boxShadow: [AppColors.primaryShadow],
      ),
      child: FloatingActionButton(
        onPressed: () => _onItemTapped(2), // Go to Home
        elevation: 0,
        backgroundColor: Colors.transparent,
        shape: const CircleBorder(),
        child: const Icon(
          Icons.home_rounded,
          color: Colors.white,
          size: 32,
        ),
      ),
    );
  }
}