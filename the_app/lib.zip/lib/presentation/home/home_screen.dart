import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/helpers.dart';
import '../../data/dummy/dummy_products.dart';
import '../../data/dummy/dummy_stores.dart';
import 'widgets/header_location_widget.dart';
import 'widgets/search_bar_widget.dart';
import 'widgets/category_item.dart';
import 'widgets/promo_banner.dart';
import 'widgets/hot_deal_card.dart';
import 'widgets/product_card.dart';
import 'widgets/store_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _selectedFilter = 'recommended';
  
  // Sample data
  final _categories = [
    {
      'icon': Icons.smartphone,
      'label': 'إلكترونيات',
      'color': AppColors.categoryElectronics
    },
    {
      'icon': Icons.checkroom,
      'label': 'أزياء',
      'color': AppColors.categoryFashion
    },
    {
      'icon': Icons.chair,
      'label': 'منزل',
      'color': AppColors.categoryHome
    },
    {
      'icon': Icons.sports_basketball,
      'label': 'رياضة',
      'color': AppColors.categorySports
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              
              // 1. Header with Location & Notifications
              HeaderLocationWidget(
                currentLocation: 'الجزائر العاصمة',
                notificationCount: 3,
                onLocationTap: () => _showLocationPicker(),
                onNotificationTap: () => _showNotifications(),
              ),

              const SizedBox(height: AppTheme.spacing20),

              // 2. Search Bar
              SearchBarWidget(
                onSearchTap: () => _navigateToSearch(),
                onFilterTap: () => _showFilters(),
              ),

              const SizedBox(height: AppTheme.spacing24),

              // 3. Categories Section
              _buildSectionHeader('الفئات', 'عرض الكل', () {}),
              const SizedBox(height: AppTheme.spacing16),
              _buildCategoriesSection(),

              const SizedBox(height: AppTheme.spacing24),

              // 4. Promo Banner
              PromoBanner(
                title: 'عرض المستخدم\nالجديد!',
                subtitle: 'احصل على خصم 15% على\nطلبك الأول',
                icon: Icons.percent,
                onTap: () => _showPromoDetails(),
              ),

              const SizedBox(height: AppTheme.spacing24),

              // 5. Hot Deals Section
              _buildHotDealsHeader(),
              const SizedBox(height: AppTheme.spacing16),
              _buildHotDealsSection(),

              const SizedBox(height: AppTheme.spacing24),

              // 6. Discover Products Section
              _buildDiscoverHeader(),
              const SizedBox(height: AppTheme.spacing16),
              _buildDiscoverFilters(),
              const SizedBox(height: AppTheme.spacing16),
              _buildProductsGrid(),

              const SizedBox(height: AppTheme.spacing24),

              // 7. Nearby Stores Section
              _buildSectionHeader('المتاجر القريبة', 'عرض الخريطة', () {}),
              const SizedBox(height: AppTheme.spacing16),
              _buildNearbyStoresSection(),

              const SizedBox(height: 100), // Space for FAB
            ],
          ),
        ),
      ),
    );
  }

  // ==================== Section Headers ====================
  
  Widget _buildSectionHeader(String title, String action, VoidCallback onActionTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: AppTextStyles.h2),
          GestureDetector(
            onTap: onActionTap,
            child: Text(
              action,
              style: AppTextStyles.linkText,
            ),
          ),
        ],
      ),
    );
  }

  // ==================== Categories Section ====================
  
  Widget _buildCategoriesSection() {
    return SizedBox(
      height: 110,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
        scrollDirection: Axis.horizontal,
        itemCount: _categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: AppTheme.spacing16),
        itemBuilder: (context, index) {
          final category = _categories[index];
          return CategoryItem(
            icon: category['icon'] as IconData,
            label: category['label'] as String,
            color: category['color'] as Color,
            onTap: () => _navigateToCategory(category['label'] as String),
          );
        },
      ),
    );
  }

  // ==================== Hot Deals Section ====================
  
  Widget _buildHotDealsHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        children: [
          // Fire Icon
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.hotDealRed,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.local_fire_department,
              color: Colors.white,
              size: 20,
            ),
          ),
          
          const SizedBox(width: AppTheme.spacing8),
          
          // Title
          const Text(
            'عروض\nساخنة',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              height: 1.1,
              fontSize: 14,
            ),
          ),
          
          const Spacer(),
          
          // Timer
          _buildTimerBox('02'),
          _buildTimerSeparator(),
          _buildTimerBox('45'),
          _buildTimerSeparator(),
          _buildTimerBox('30'),
        ],
      ),
    );
  }

  Widget _buildTimerBox(String time) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.textPrimary,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        time,
        style: AppTextStyles.timerText,
      ),
    );
  }

  Widget _buildTimerSeparator() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 4),
      child: Text(
        ':',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildHotDealsSection() {
    final hotDeals = DummyProducts.hotDeals;
    
    return SizedBox(
      height: 220,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
        scrollDirection: Axis.horizontal,
        itemCount: hotDeals.length,
        separatorBuilder: (_, __) => const SizedBox(width: AppTheme.spacing16),
        itemBuilder: (context, index) {
          return HotDealCard(
            product: hotDeals[index],
            onTap: () => _navigateToProductDetails(hotDeals[index]),
          );
        },
      ),
    );
  }

  // ==================== Discover Section ====================
  
  Widget _buildDiscoverHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('اكتشف المنتجات', style: AppTextStyles.h2),
          Text(
            'عرض الكل',
            style: AppTextStyles.linkText,
          ),
        ],
      ),
    );
  }

  Widget _buildDiscoverFilters() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        children: [
          _buildFilterChip(
            'موصى به',
            Icons.trending_up,
            _selectedFilter == 'recommended',
            () => setState(() => _selectedFilter = 'recommended'),
          ),
          const SizedBox(width: 10),
          _buildFilterChip(
            'قريب منك',
            Icons.near_me_outlined,
            _selectedFilter == 'nearby',
            () => setState(() => _selectedFilter = 'nearby'),
          ),
          const SizedBox(width: 10),
          _buildFilterChip(
            'الأعلى تقييماً',
            Icons.star_outline,
            _selectedFilter == 'top_rated',
            () => setState(() => _selectedFilter = 'top_rated'),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(
    String label,
    IconData icon,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          gradient: isSelected ? AppColors.primaryGradient : null,
          color: isSelected ? null : Colors.white,
          borderRadius: AppTheme.mediumRadius,
          border: isSelected ? null : Border.all(color: AppColors.borderLight),
          boxShadow: isSelected ? [AppColors.primaryShadow] : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 18,
              color: isSelected ? Colors.white : AppColors.textPrimary,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : AppColors.textPrimary,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductsGrid() {
    final products = DummyProducts.recommendedProducts;
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          mainAxisSpacing: AppTheme.spacing16,
          crossAxisSpacing: AppTheme.spacing16,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductCard(
            product: products[index],
            onTap: () => _navigateToProductDetails(products[index]),
            onFavoriteTap: () => _toggleFavorite(products[index]),
          );
        },
      ),
    );
  }

  // ==================== Nearby Stores Section ====================
  
  Widget _buildNearbyStoresSection() {
    final stores = DummyStores.nearbyStores.take(3).toList();
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Column(
        children: stores.map((store) {
          return Padding(
            padding: const EdgeInsets.only(bottom: AppTheme.spacing12),
            child: StoreCard(
              store: store,
              onTap: () => _navigateToStoreDetails(store),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ==================== Navigation Methods ====================
  
  void _showLocationPicker() {
    Helpers.showSnackBar(context, 'اختيار الموقع قريباً');
  }

  void _showNotifications() {
    Helpers.showSnackBar(context, 'لديك 3 إشعارات جديدة');
  }

  void _navigateToSearch() {
    Helpers.showSnackBar(context, 'البحث قريباً');
  }

  void _showFilters() {
    Helpers.showSnackBar(context, 'الفلاتر قريباً');
  }

  void _navigateToCategory(String category) {
    Helpers.showSnackBar(context, 'فئة: $category');
  }

  void _showPromoDetails() {
    Helpers.showSnackBar(context, 'عرض المستخدم الجديد');
  }

  void _navigateToProductDetails(product) {
    Helpers.showSnackBar(context, 'تفاصيل: ${product.name}');
  }

  void _toggleFavorite(product) {
    Helpers.showSnackBar(context, 'تمت الإضافة إلى المفضلة');
  }

  void _navigateToStoreDetails(store) {
    Helpers.showSnackBar(context, 'متجر: ${store.name}');
  }
}