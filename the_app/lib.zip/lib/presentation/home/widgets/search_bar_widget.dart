import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../core/theme/app_theme.dart';

class SearchBarWidget extends StatelessWidget {
  final VoidCallback? onSearchTap;
  final VoidCallback? onFilterTap;
  final String hintText;

  const SearchBarWidget({
    super.key,
    this.onSearchTap,
    this.onFilterTap,
    this.hintText = 'ابحث عن المنتجات، المتاجر...',
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        children: [
          // Filter Button
          Container(
            height: 55,
            width: 55,
            decoration: BoxDecoration(
              gradient: AppColors.primaryGradient,
              borderRadius: AppTheme.mediumRadius,
              boxShadow: [AppColors.primaryShadow],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onFilterTap,
                borderRadius: AppTheme.mediumRadius,
                child: const Icon(
                  Icons.tune_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ),
          ),
          
          const SizedBox(width: AppTheme.spacing12),
          
          // Search Field
          Expanded(
            child: GestureDetector(
              onTap: onSearchTap,
              child: Container(
                height: 55,
                padding: const EdgeInsets.symmetric(
                  horizontal: AppTheme.spacing16,
                ),
                decoration: BoxDecoration(
                  color: AppColors.searchBarBackground,
                  borderRadius: AppTheme.mediumRadius,
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.search_rounded,
                      color: AppColors.textHint,
                      size: 28,
                    ),
                    const SizedBox(width: AppTheme.spacing12),
                    Expanded(
                      child: Text(
                        hintText,
                        style: AppTextStyles.hintText,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
