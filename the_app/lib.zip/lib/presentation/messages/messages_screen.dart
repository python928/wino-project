import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/theme/app_theme.dart';
import '../shared_widgets/custom_app_bar.dart';
import '../shared_widgets/empty_state_widget.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Sample messages data
    final messages = [
      {
        'storeName': 'تيك زون',
        'message': 'شكراً لتواصلك معنا',
        'time': '10:30 ص',
        'unread': 2,
        'avatar': 'https://images.unsplash.com/photo-1531297461136-82f5fca919b?w=100',
      },
      {
        'storeName': 'فاشن هب',
        'message': 'المنتج متوفر الآن',
        'time': 'أمس',
        'unread': 0,
        'avatar': 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=100',
      },
    ];

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: const CustomAppBar(
        title: 'الرسائل',
        showBackButton: false,
        actions: [
          Padding(
            padding: EdgeInsets.only(left: 16),
            child: Icon(Icons.edit_outlined, color: AppColors.textPrimary),
          ),
        ],
      ),
      body: messages.isEmpty
          ? const EmptyStateWidget(
              icon: Icons.chat_bubble_outline,
              title: 'لا توجد رسائل',
              message: 'ابدأ محادثة مع المتاجر للحصول على الدعم',
            )
          : ListView.separated(
              padding: const EdgeInsets.symmetric(
                vertical: AppTheme.spacing16,
              ),
              itemCount: messages.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final message = messages[index];
                return _buildMessageTile(
                  storeName: message['storeName'] as String,
                  message: message['message'] as String,
                  time: message['time'] as String,
                  unreadCount: message['unread'] as int,
                  avatarUrl: message['avatar'] as String,
                );
              },
            ),
    );
  }

  Widget _buildMessageTile({
    required String storeName,
    required String message,
    required String time,
    required int unreadCount,
    required String avatarUrl,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing20,
        vertical: AppTheme.spacing8,
      ),
      leading: Stack(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundImage: NetworkImage(avatarUrl),
          ),
          if (unreadCount > 0)
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: const BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
                constraints: const BoxConstraints(
                  minWidth: 18,
                  minHeight: 18,
                ),
                child: Text(
                  unreadCount.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
      title: Text(
        storeName,
        style: AppTextStyles.bodyLarge.copyWith(
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Text(
        message,
        style: AppTextStyles.bodySmall.copyWith(
          color: unreadCount > 0 
              ? AppColors.textPrimary 
              : AppColors.textSecondary,
          fontWeight: unreadCount > 0 
              ? FontWeight.w500 
              : FontWeight.normal,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(
            time,
            style: AppTextStyles.bodySmall.copyWith(
              color: unreadCount > 0 
                  ? AppColors.primaryPurple 
                  : AppColors.textHint,
              fontWeight: unreadCount > 0 
                  ? FontWeight.bold 
                  : FontWeight.normal,
            ),
          ),
          if (unreadCount > 0) ...[
            const SizedBox(height: 4),
            Container(
              width: 8,
              height: 8,
              decoration: const BoxDecoration(
                color: AppColors.primaryPurple,
                shape: BoxShape.circle,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
