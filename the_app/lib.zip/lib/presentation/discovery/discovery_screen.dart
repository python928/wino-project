import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/theme/app_theme.dart';
import '../../data/dummy/dummy_products.dart';
import '../shared_widgets/custom_app_bar.dart';
import '../home/widgets/product_card.dart';
import '../shared_widgets/empty_state_widget.dart';

class DiscoveryScreen extends StatefulWidget {
  const DiscoveryScreen({super.key});

  @override
  State<DiscoveryScreen> createState() => _DiscoveryScreenState();
}

class _DiscoveryScreenState extends State<DiscoveryScreen> {
  String _selectedCategory = 'الكل';
  String _selectedSort = 'الأحدث';

  final List<String> _categories = [
    'الكل',
    'إلكترونيات',
    'أزياء',
    'منزل',
    'رياضة',
  ];

  final List<String> _sortOptions = [
    'الأحدث',
    'الأعلى تقييماً',
    'الأقل سعراً',
    'الأعلى سعراً',
  ];

  @override
  Widget build(BuildContext context) {
    final products = DummyProducts.getAllProducts();

    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      appBar: const CustomAppBar(
        title: 'استكشاف',
        showBackButton: false,
        actions: [
          Padding(
            padding: EdgeInsets.only(left: 16),
            child: Icon(Icons.search, color: AppColors.textPrimary),
          ),
        ],
      ),
      body: Column(
        children: [
          // Categories Filter
          SizedBox(
            height: 50,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(
                horizontal: AppTheme.spacing20,
                vertical: AppTheme.spacing8,
              ),
              scrollDirection: Axis.horizontal,
              itemCount: _categories.length,
              separatorBuilder: (_, __) => const SizedBox(
                width: AppTheme.spacing12,
              ),
              itemBuilder: (context, index) {
                final category = _categories[index];
                final isSelected = category == _selectedCategory;
                
                return _buildFilterChip(
                  category,
                  isSelected,
                  () => setState(() => _selectedCategory = category),
                );
              },
            ),
          ),

          // Sort Options
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppTheme.spacing20,
              vertical: AppTheme.spacing12,
            ),
            child: Row(
              children: [
                Icon(
                  Icons.sort,
                  size: 20,
                  color: AppColors.textSecondary,
                ),
                const SizedBox(width: AppTheme.spacing8),
                Text(
                  'ترتيب حسب:',
                  style: AppTextStyles.bodySmall,
                ),
                const SizedBox(width: AppTheme.spacing8),
                Expanded(
                  child: DropdownButton<String>(
                    value: _selectedSort,
                    isExpanded: true,
                    underline: const SizedBox(),
                    items: _sortOptions.map((sort) {
                      return DropdownMenuItem(
                        value: sort,
                        child: Text(
                          sort,
                          style: AppTextStyles.bodyMedium.copyWith(
                            color: AppColors.primaryPurple,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _selectedSort = value);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Products Grid
          Expanded(
            child: products.isEmpty
                ? const EmptyStateWidget(
                    icon: Icons.search_off,
                    title: 'لا توجد منتجات',
                    message: 'لم نجد أي منتجات تطابق بحثك',
                  )
                : GridView.builder(
                    padding: const EdgeInsets.all(AppTheme.spacing20),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      mainAxisSpacing: AppTheme.spacing16,
                      crossAxisSpacing: AppTheme.spacing16,
                    ),
                    itemCount: products.length,
                    itemBuilder: (context, index) {
                      return ProductCard(
                        product: products[index],
                        onTap: () {},
                        onFavoriteTap: () {},
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppTheme.spacing16,
          vertical: AppTheme.spacing8,
        ),
        decoration: BoxDecoration(
          gradient: isSelected ? AppColors.primaryGradient : null,
          color: isSelected ? null : Colors.white,
          borderRadius: AppTheme.mediumRadius,
          border: isSelected 
              ? null 
              : Border.all(color: AppColors.borderLight),
          boxShadow: isSelected ? [AppColors.primaryShadow] : [],
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : AppColors.textPrimary,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}
