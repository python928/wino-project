import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/helpers.dart';
import '../../data/dummy/store_model.dart';
import '../../data/dummy/dummy_products.dart';
import '../shared_widgets/gradient_button.dart';
import '../home/widgets/product_card.dart';

class StoreDetailsScreen extends StatefulWidget {
  final Store store;

  const StoreDetailsScreen({
    super.key,
    required this.store,
  });

  @override
  State<StoreDetailsScreen> createState() => _StoreDetailsScreenState();
}

class _StoreDetailsScreenState extends State<StoreDetailsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool isFollowing = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.scaffoldBackground,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(),
          SliverToBoxAdapter(
            child: Column(
              children: [
                _buildStoreInfo(),
                const SizedBox(height: AppTheme.spacing24),
                _buildActionButtons(),
                const SizedBox(height: AppTheme.spacing24),
                _buildStats(),
                const SizedBox(height: AppTheme.spacing24),
              ],
            ),
          ),
          _buildTabBar(),
          SliverToBoxAdapter(
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.6,
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildProductsTab(),
                  _buildAboutTab(),
                  _buildReviewsTab(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      expandedHeight: 200,
      pinned: true,
      backgroundColor: Colors.white,
      leading: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          boxShadow: [AppColors.softShadow],
        ),
        child: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [AppColors.softShadow],
          ),
          child: IconButton(
            icon: const Icon(Icons.share, color: AppColors.textPrimary),
            onPressed: () => Helpers.showSnackBar(context, 'مشاركة المتجر'),
          ),
        ),
      ],
      flexibleSpace: FlexibleSpaceBar(
        background: Hero(
          tag: 'store-${widget.store.id}',
          child: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(widget.store.imageUrl),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.3),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStoreInfo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.store.name, style: AppTextStyles.h2),
                    const SizedBox(height: AppTheme.spacing4),
                    Text(widget.store.category, style: AppTextStyles.bodySmall),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: widget.store.isOpen
                      ? AppColors.successGreen.withOpacity(0.1)
                      : AppColors.error.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  widget.store.isOpen ? 'مفتوح' : 'مغلق',
                  style: AppTextStyles.bodySmall.copyWith(
                    color: widget.store.isOpen
                        ? AppColors.successGreen
                        : AppColors.error,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppTheme.spacing12),
          Row(
            children: [
              Icon(
                Icons.location_on_outlined,
                size: 16,
                color: AppColors.textSecondary,
              ),
              Text(
                ' ${Helpers.formatDistance(widget.store.distance)} من موقعك',
                style: AppTextStyles.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        children: [
          Expanded(
            child: GradientButton(
              text: isFollowing ? 'متابَع' : 'متابعة',
              icon: isFollowing ? Icons.check : Icons.add,
              onPressed: () {
                setState(() => isFollowing = !isFollowing);
                Helpers.showSnackBar(
                  context,
                  isFollowing ? 'تمت المتابعة' : 'تم إلغاء المتابعة',
                );
              },
              gradient: isFollowing ? null : AppColors.primaryGradient,
            ),
          ),
          const SizedBox(width: AppTheme.spacing12),
          Container(
            height: 55,
            width: 55,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primaryPurple, width: 2),
              borderRadius: AppTheme.mediumRadius,
            ),
            child: IconButton(
              icon: const Icon(
                Icons.chat_bubble_outline,
                color: AppColors.primaryPurple,
              ),
              onPressed: () => Helpers.showSnackBar(context, 'مراسلة المتجر'),
            ),
          ),
          const SizedBox(width: AppTheme.spacing12),
          Container(
            height: 55,
            width: 55,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primaryPurple, width: 2),
              borderRadius: AppTheme.mediumRadius,
            ),
            child: IconButton(
              icon: const Icon(Icons.call, color: AppColors.primaryPurple),
              onPressed: () => Helpers.showSnackBar(context, 'الاتصال بالمتجر'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppTheme.spacing20),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'المتابعون',
              Helpers.formatLargeNumber(widget.store.followers),
              Icons.people,
            ),
          ),
          const SizedBox(width: AppTheme.spacing12),
          Expanded(
            child: _buildStatCard(
              'التقييم',
              Helpers.formatRating(widget.store.rating),
              Icons.star,
            ),
          ),
          const SizedBox(width: AppTheme.spacing12),
          Expanded(
            child: _buildStatCard('المنتجات', '120', Icons.inventory_2),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: AppTheme.mediumRadius,
        boxShadow: [AppColors.softShadow],
      ),
      child: Column(
        children: [
          Icon(icon, color: AppColors.primaryPurple),
          const SizedBox(height: AppTheme.spacing8),
          Text(
            value,
            style: AppTextStyles.h3.copyWith(color: AppColors.primaryPurple),
          ),
          Text(label, style: AppTextStyles.bodySmall),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return SliverPersistentHeader(
      pinned: true,
      delegate: _SliverAppBarDelegate(
        TabBar(
          controller: _tabController,
          labelColor: AppColors.primaryPurple,
          unselectedLabelColor: AppColors.textHint,
          indicatorColor: AppColors.primaryPurple,
          labelStyle:
              AppTextStyles.bodyMedium.copyWith(fontWeight: FontWeight.bold),
          tabs: const [
            Tab(text: 'المنتجات'),
            Tab(text: 'عن المتجر'),
            Tab(text: 'التقييمات'),
          ],
        ),
      ),
    );
  }

  Widget _buildProductsTab() {
    final products = DummyProducts.recommendedProducts.take(4).toList();
    
    return Padding(
      padding: const EdgeInsets.all(AppTheme.spacing20),
      child: GridView.builder(
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          mainAxisSpacing: AppTheme.spacing16,
          crossAxisSpacing: AppTheme.spacing16,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductCard(
            product: products[index],
            onTap: () => Helpers.showSnackBar(context, 'تفاصيل المنتج'),
            onFavoriteTap: () => Helpers.showSnackBar(context, 'المفضلة'),
          );
        },
      ),
    );
  }

  Widget _buildAboutTab() {
    return Padding(
      padding: const EdgeInsets.all(AppTheme.spacing20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('عن المتجر', style: AppTextStyles.h3),
          const SizedBox(height: AppTheme.spacing12),
          Text(
            widget.store.description ??
                'متجر متخصص في بيع المنتجات عالية الجودة. نفخر بتقديم أفضل الخدمات لعملائنا.',
            style: AppTextStyles.bodyMedium.copyWith(height: 1.6),
          ),
          const SizedBox(height: AppTheme.spacing24),
          Text('أوقات العمل', style: AppTextStyles.h3),
          const SizedBox(height: AppTheme.spacing12),
          _buildWorkingHour('السبت - الخميس', '09:00 - 21:00'),
          _buildWorkingHour('الجمعة', '14:00 - 21:00'),
        ],
      ),
    );
  }

  Widget _buildWorkingHour(String day, String hours) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.spacing8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(day, style: AppTextStyles.bodyMedium),
          Text(
            hours,
            style: AppTextStyles.bodyMedium.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReviewsTab() {
    return Padding(
      padding: const EdgeInsets.all(AppTheme.spacing20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('التقييمات', style: AppTextStyles.h3),
          const SizedBox(height: AppTheme.spacing12),
          Text(
            'متوسط التقييم: ${Helpers.formatRating(widget.store.rating)} ⭐',
            style: AppTextStyles.bodyMedium,
          ),
          const SizedBox(height: AppTheme.spacing16),
          Text('قريباً: عرض جميع التقييمات', style: AppTextStyles.bodySmall),
        ],
      ),
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(
      color: Colors.white,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}
