
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/theme/app_theme.dart';
import 'core/constants/app_constants.dart';
import 'presentation/auth/splash_screen.dart';

void main() {
  runApp(const DzLocalApp());
}

class DzLocalApp extends StatelessWidget {
  const DzLocalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      
      // Localization
      locale: const Locale(
        AppConstants.arabicLanguageCode,
        AppConstants.algeriaCountryCode,
      ),
      supportedLocales: const [
        Locale(AppConstants.arabicLanguageCode, AppConstants.algeriaCountryCode),
        Locale(AppConstants.englishLanguageCode, AppConstants.usCountryCode),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      
      // Theme
      theme: AppTheme.lightTheme,
      
      // Start with Splash Screen
      home: const SplashScreen(),
    );
  }
}
